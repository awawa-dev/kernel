#include <asm-generic/mcs_spinlock.h>
